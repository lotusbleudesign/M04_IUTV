import java.util.*; 

public class Banque  {
	//private Vector <Compte> comptes;
	private Map<String, Compte> comptes;
	private Compte compte;

	Banque () {
		comptes = new HashMap<>();
	}

    
	public void ouvrirCompte (String nom, String mdp) throws RuntimeException {
		if (this.comptes.containsKey(nom)){
            if(this.comptes.get(nom).getMdp().equals(mdp)) {
                throw new RuntimeException ("Compte déjà existant dans la base de données");
            }
		} else {
			this.compte = new Compte(nom,0,mdp);
			comptes.put(nom, compte);
			comptes.get(nom).setSolde(0);
			System.out.println("Un compte a été crée");
		}
	}

    
	public Compte verifie (String nom, String mdp) throws RuntimeException {

		Compte compteTemp = new Compte();
		if(comptes.containsKey(nom)) {
            if(comptes.get(nom).getMdp().equals(mdp)) {
               //compteTemp = new Compte(this.comptes.get(nom).getCompte());
               compteTemp.setCompte(this.compte.getCompte());
            }
		}
		else {
            throw new RuntimeException ("Compte inexistant dans la base de données");
		}
		
		//return comptes.get(nom);
		//return this.comptes.get(nom)s.getCompte();
		return compteTemp.getCompte();
	}
	
	/*public void verifie (String nom, String mdp, Compte compte) {
        Compte c = new Compte(this.verifie(nom, mdp));
        System.out.println("Bonjour " + nom +", *******************************");
        System.out.println("Votre solde sur votre compte courant est de : " + c.getSolde() + " €." );
        System.out.println("Votre mot de passe : " + c.getMdp() + " €." );
        System.out.println("Fin opération******* *******************************" );
	}*/

	public Compte getCompte (String idCompte, String mdp) throws RuntimeException {
        Compte compteTemp = new Compte();
        if(this.comptes.containsKey(idCompte)) {
            if(this.comptes.get(idCompte).getMdp().equals(mdp)){
                compteTemp.setCompte(this.comptes.get(idCompte).getCompte());
            }
        } 
        else {
            throw new RuntimeException ("Erreur nom d'utilisateur ou mot de passe ");
            //return 0;
        }
        return compteTemp;
	}
	public int fermerCompte (String nom, String mdp) {
		int soldeTempo = 0;
        if(comptes.containsKey(nom)) {
            if(comptes.get(nom).getMdp().equals(mdp)) {
                soldeTempo = this.solde(comptes.get(nom));
                comptes.remove(nom);
            }
        }

		return soldeTempo;
	}

	public int solde(Compte compte) {
		return compte.getSolde();
	}

	public void deposer (int somme, Compte compte) {
		this.compte.setSolde(somme + compte.getSolde());
	}

	public void retirer (int somme, Compte compte) {
		int operationSoldeTempo = compte.getSolde()-somme;
		compte.setSolde(operationSoldeTempo);
	}
}
