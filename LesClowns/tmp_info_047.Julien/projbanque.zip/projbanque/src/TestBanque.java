public class TestBanque {
  public static void main(String [] args) {
    Banque banqueDescartes = new Banque();
    String name = "Kevin2", mdp = "bg";
    banqueDescartes.ouvrirCompte(name,mdp);
    
    try {
        System.out.println("Ouvrir un compte avec l'user Julien et le mot de passe bg");
        banqueDescartes.ouvrirCompte(name, mdp);
    }
    catch (RuntimeException e) {}
    
    try {
        banqueDescartes.deposer(200, banqueDescartes.getCompte(name, mdp));
    }
    catch (RuntimeException e) {}
    System.out.println("Fermeture du compte, solde actualisé : " + banqueDescartes.fermerCompte(name, mdp));
    /* FONCTIONNE
    System.out.println("Vérification de l'exception :");
    banqueDescartes.ouvrirCompte(name, mdp);
    
    System.out.println("Test verif");
    banqueDescartes.verifie(name, mdp, banqueDescartes.getCompte(name, "DescartesAdmin", "VilletaneuseMdp"));
    */
    
     
  } 
}
